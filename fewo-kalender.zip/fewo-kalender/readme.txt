=== Fewo Kalender ===
Contributors: your-name
Tags: calendar, booking, vacation rental
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.1.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Ein einfaches WordPress-Plugin fuer mehrere Ferienwohnungs-Belegungskalender.

== Description ==
- Beliebig viele Kalender erstellen
- Tagesstatus: frei, belegt, Wechseltag
- Backend Monatsansicht mit Klick-Bedienung
- Frontend Anzeige per Shortcode
- Design pro Kalender waehlbar (Modern, Ocean, Terracotta)
- Responsive Layout, keine Buchungsfunktion

== Installation ==
1. Plugin als ZIP hochladen oder in wp-content/plugins entpacken.
2. Plugin in WordPress aktivieren.
3. Unter "Fewo Kalender" Kalender anlegen.
4. Shortcode verwenden: [fewo_kalender id="1"]
5. Optionales Design im Shortcode: [fewo_kalender id="1" design="ocean"]

== Support ==
Wenn dir dieses Plugin hilft, kannst du mich hier unterstuetzen:
https://buymeacoffee.com/worklessit

== Changelog ==
= 1.1.6 =
* Firmen-Werbeblock im Backend visuell aufgewertet (Logo-Badge, klarerer CTA, modernes Layout).

= 1.1.5 =
* Firmen-Werbeflaeche im Backend hinzugefuegt (Work Less IT): https://work-less.it/

= 1.1.4 =
* Support-Link jetzt sichtbar direkt im Plugin-Backend (Fewo Kalender + Bearbeiten).
* Der Admin-Menuepunkt fewo-kalender-edit ist nicht mehr sichtbar und nur noch intern aufrufbar.

= 1.1.3 =
* README/Support-Bereich erweitert.
* Buy Me a Coffee Link hinzugefuegt: https://buymeacoffee.com/worklessit

= 1.1.2 =
* Live-Highlight der Design-Vorschau im Admin beim Wechsel der Design-Auswahl.

= 1.1.1 =
* Design-Vorschau im Admin beim Anlegen und Bearbeiten eines Kalenders hinzugefuegt.

= 1.1.0 =
* Moderneres Frontend-Design.
* Design-Auswahl pro Kalender im Admin.
* Drei Designvarianten: Modern, Ocean, Terracotta.
* Upgrade-Logik fuer bestehende Installationen (neues Feld "design").

= 1.0.0 =
* Erste stabile Version.
